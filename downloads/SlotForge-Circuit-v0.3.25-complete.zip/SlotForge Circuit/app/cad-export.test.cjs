const test=require('node:test'),assert=require('node:assert/strict'),F=require('./core.js'),R=F.Routed,C=require('./cad-export.js');
const circular=()=>structuredClone(require('../integration/slotforge-timing/routed-examples/closed-routed-oval.slotforge.json'));
const flowing=()=>structuredClone(require('../integration/slotforge-timing/routed-examples/closed-flowing-track.slotforge.json'));
const only={slots:true,slotEdges:false,conductors:false,surfaces:false,table:false,timing:false,scale:false};
test('Black SVG display lines stay visible without changing paths, layers, dimensions or scale',()=>{
 const model=C.build(flowing()),before=structuredClone(model),paths=s=>[...s.matchAll(/<path\b[^>]*>/g)].map(m=>m[0]),attr=(s,key)=>s.match(new RegExp(key+'="([^"]+)"'))[1];
 const fine=C.serializeSVG(model,false,1,'layers'),black=C.serializeSVG(model);
 assert.deepEqual(paths(black),paths(fine));assert.equal(attr(black,'viewBox'),attr(fine,'viewBox'));assert.equal(attr(black,'width'),attr(fine,'width'));assert.equal(attr(black,'height'),attr(fine,'height'));
 assert.deepEqual([...black.matchAll(/\bstroke="([^"]+)"/g)].map(m=>m[1]),model.layers.map(()=>'#000000'));
 const weight=Number(attr(black,'stroke-width'));assert.ok(weight>.25);assert.ok(weight/Math.max(model.bounds[2]+10,model.bounds[3]+10)*500>=.9999);
 assert.equal(attr(fine,'stroke-width'),'0.25');for(const layer of model.layers)assert.ok(fine.includes('stroke="'+layer.color+'"'));
 for(const scale of[5,50,'compact']){const scaled=C.serializeSVG(model,false,scale);assert.deepEqual(paths(scaled),paths(black));assert.equal(attr(scaled,'stroke-width'),attr(black,'stroke-width'));assert.equal(attr(scaled,'viewBox'),attr(black,'viewBox'));}
 assert.deepEqual(model,before);assert.match(black,/visibility only, not slot width/);
});
test('SVG preview respects appearance and malformed appearance is rejected',()=>{
 const model=C.build(circular());assert.match(C.preview(model),/stroke="#000000"/);assert.match(C.preview(model,'layers'),/stroke="#2563a5"/);assert.match(C.preview(model),/vector-effect="non-scaling-stroke"/);
 for(const bad of['white','',null,{},'<script>'])assert.throws(()=>C.serializeSVG(model,false,1,bad),/SVG appearance/);
 assert.equal(C.svg(circular(),undefined,1,'layers'),C.serializeSVG(model,false,1,'layers'));
});
test('Large SVG pages contain the full visible strokes at every edge and scale',()=>{
 const model=C.build(circular());model.bounds=[-200,300,10000,5000];
 const attr=(s,key)=>s.match(new RegExp(key+'="([^"]+)"'))[1];
 for(const scale of[1,50,'compact']){
  const black=C.serializeSVG(model,false,scale),fine=C.serializeSVG(model,false,scale,'layers'),box=attr(black,'viewBox').split(' ').map(Number),half=Number(attr(black,'stroke-width'))/2;
  assert.ok(model.bounds[0]-box[0]>=half);assert.ok(model.bounds[1]-box[1]>=half);
  assert.ok(box[0]+box[2]-model.bounds[0]-model.bounds[2]>=half);assert.ok(box[1]+box[3]-model.bounds[1]-model.bounds[3]>=half);
  assert.equal(attr(fine,'viewBox'),attr(black,'viewBox'));assert.equal(attr(C.preview(model),'viewBox'),attr(black,'viewBox'));
  const size=C.svgSize(model,scale);close(parseFloat(attr(black,'width'))*size.denominator,box[2],.001);close(parseFloat(attr(black,'height'))*size.denominator,box[3],.001);
 }
});
test('A piece contour remains closed when its near-identical end meets tabletop routing',()=>{const s=R.settings({...R.defaults,slotWidthMm:2,conductorGapMm:1,conductorWidthMm:8,innerClearanceMm:10.000001,outerClearanceMm:10.000001}),a=R.definition(s,{type:'straight',lengthMm:500},'piece'),b=R.definition({...s,constructionMode:'table'},{type:'straight',lengthMm:500},'table'),defs={[a.id]:a,[b.id]:b},p=F.pose(a),q=F.join(F.pose(b),b,0,F.ports(p,defs)[1]),m=C.build(raw([a,b],[p,q]),{...only,slots:false,surfaces:true});assert.equal(m.removedCaps,0);const cuts=m.paths.filter(p=>p.layer==='SURFACE_EDGES');assert.equal(cuts.length,1);assert.equal(cuts[0].closed,true);});
const close=(a,b,t=1e-5)=>assert.ok(Math.abs(a-b)<t,`${a} != ${b}`);
function raw(defs,pieces){return{format:'slotforge.layout',version:1,title:'CAD test',definitions:defs,pieces};}
function tags(text){const lines=text.trimEnd().split(/\r?\n/);assert.equal(lines.length%2,0);return Array.from({length:lines.length/2},(_,i)=>[Number(lines[2*i]),lines[2*i+1]]);}
function entities(dxf){const pairs=tags(dxf),out=[];let active=false,current=null;for(let i=0;i<pairs.length;i++){const [code,value]=pairs[i];if(code===2&&value==='ENTITIES'){active=true;continue;}if(!active)continue;if(code===0){if(current)out.push(current);current=null;if(value==='ENDSEC')break;if(value==='LWPOLYLINE')current=[];}else if(current)current.push([code,value]);}return out;}

test('A closed circular layout exports continuous slots and surface contours without internal section seams',()=>{const m=C.build(circular(),{...only,surfaces:true});assert.equal(m.routedSections,6);assert.equal(m.removedCaps,12);assert.equal(m.paths.length,4);assert.ok(m.paths.every(p=>p.closed));assert.equal(m.paths.filter(p=>p.layer==='SLOT_CENTRES').length,2);assert.equal(m.paths.filter(p=>p.layer==='SURFACE_EDGES').length,2);assert.ok(m.paths.every(p=>p.bulges.filter(Boolean).length===4));});
test('Reflecting and rotating an entire circuit preserves joined contours and removes the same seams',()=>{const layout=circular();layout.pieces=F.repositionGroup(layout.pieces,{x:0,y:0,angle:0,flip:false},{x:123,y:-456,angle:37,flip:true});const m=C.build(layout,{...only,surfaces:true});assert.equal(m.removedCaps,12);assert.equal(m.paths.length,4);assert.ok(m.paths.every(p=>p.closed));});
test('Drawing bounds include arc extrema between their endpoints',()=>{const d=R.definition(R.settings(),{type:'curve',slotRadiusMm:300,angleDeg:90}),p={...F.pose(d),angle:45},m=C.build(raw([d],[p]),only);close(m.bounds[0],300*Math.SQRT1_2);close(m.bounds[0]+m.bounds[2],400);close(m.bounds[1],-400*Math.SQRT1_2);close(m.bounds[3],800*Math.SQRT1_2);});
test('An open routed straight has two slot lines and one closed rectangular surface',()=>{const d=R.definition(R.settings(),{type:'straight',lengthMm:1000}),p={...F.pose(d),x:123,y:-456},m=C.build(raw([d],[p]),{...only,surfaces:true});assert.equal(m.openSlots,4);const outline=m.paths.find(p=>p.layer==='SURFACE_EDGES');assert.equal(outline.closed,true);assert.equal(outline.points.length,4);assert.deepEqual(m.bounds,[123,-456,1000,300]);});
test('Slot and conductor boundaries use the physical widths at normal offsets',()=>{const s=R.settings(),d=R.definition(s,{type:'routed-spline',controlPointsMm:R.Spline.preset('bend',s)}),m=C.build(raw([d],[F.pose(d)]),{...only,slots:false,slotEdges:true,conductors:true});assert.equal(m.paths.length,12);const edges=m.paths.filter(p=>p.layer==='SLOT_EDGES'),metal=m.paths.filter(p=>p.layer==='BRAID_EDGES');close(F.dist(edges[0].points[0],edges[1].points[0]),s.slotWidthMm);for(let i=0;i<metal.length;i+=2)close(F.dist(metal[i].points[0],metal[i+1].points[0]),s.conductorWidthMm);assert.ok(m.paths.every(p=>p.bulges.every(b=>b===0)));});
test('Flowing centrelines are the same sampled paths used by the editor',()=>{const s=R.settings({ ...R.defaults,laneCount:3,laneSpacingMm:90}),d=R.definition(s,{type:'routed-spline',controlPointsMm:R.Spline.preset('s-bend',s)}),p={...F.pose(d),x:-123.4,y:567.8,angle:37,flip:true},m=C.build(raw([d],[p]),only);for(const [i,path]of m.paths.entries()){const expected=d.geometry.lanePaths[i].segments[0].points.map(q=>F.point(q,p));assert.deepEqual(path.points,expected);}assert.equal(m.sampled,true);});
test('DXF preserves native arc bulges under both reflection and rotation, with CAD Y pointing up',()=>{const d=R.definition(R.settings(),{type:'curve',slotRadiusMm:300,angleDeg:90});for(const flip of[false,true]){const p={...F.pose(d),x:135.2,y:-90.8,angle:47,flip},layout=raw([d],[p]),m=C.build(layout,only),out=entities(C.dxf(layout,only));assert.equal(out.length,m.paths.length);for(let i=0;i<out.length;i++){const pairs=out[i],xs=pairs.filter(p=>p[0]===10).map(p=>+p[1]),ys=pairs.filter(p=>p[0]===20).map(p=>+p[1]),bulges=pairs.filter(p=>p[0]===42).map(p=>+p[1]);for(let j=0;j<xs.length;j++){close(xs[j],m.paths[i].points[j][0]);close(ys[j],-m.paths[i].points[j][1]);}close(bulges[0],-m.paths[i].bulges[0]);close(Math.abs(bulges[0]),Math.tan(Math.PI/8));}}});
test('DXF headers declare millimetres and use layer names and closed flags consistently',()=>{const layout=flowing(),out=C.dxf(layout),pairs=tags(out),m=C.build(layout);assert.match(out,/\$ACADVER\r\n\s*1\r\nAC1015/);assert.match(out,/\$INSUNITS\r\n\s*70\r\n4/);assert.match(out,/\$MEASUREMENT\r\n\s*70\r\n1/);const es=entities(out);assert.equal(es.length,m.paths.length);for(const e of es){assert.ok(m.layers.some(l=>l.id===e.find(p=>p[0]===8)[1]));assert.equal(+e.find(p=>p[0]===70)[1],1);}assert.deepEqual(pairs.at(-1),[0,'EOF']);});
test('Shallow circular arcs retain dimensionless bulge precision independently of mm coordinate precision',()=>{const d=R.definition(R.settings(),{type:'curve',slotRadiusMm:10000,angleDeg:.01}),out=entities(C.dxf(raw([d],[F.pose(d)]),only));for(const e of out)close(+e.find(p=>p[0]===42)[1],-Math.tan(F.rad(.01)/4),1e-12);});
test('SVG is physically full size, flattened into world millimetres and split into named layers',()=>{const layout=flowing(),m=C.build(layout),svg=C.svg(layout),root=svg.match(/<svg\b[^>]*>/)[0],w=+root.match(/width="([\d.]+)mm"/)[1],h=+root.match(/height="([\d.]+)mm"/)[1],box=root.match(/viewBox="([^"]+)"/)[1].split(' ').map(Number);close(w,box[2]);close(h,box[3]);close(w,m.bounds[2]+10);close(h,m.bounds[3]+10);assert.match(svg,/inkscape:groupmode="layer"/);assert.match(svg,/id="SLOT_CENTRES"/);assert.doesNotMatch(svg,/<image|<script|href=|transform=|NaN|Infinity/);});
test('Turning a layer off omits it from both vector formats; table and timing availability are explicit',()=>{const layout=flowing(),m=C.build(layout,{...only,conductors:true,timing:true});assert.equal(m.tableAvailable,true);assert.equal(m.timingAvailable,true);assert.ok(m.layers.some(l=>l.id==='TIMING_LINE'));assert.ok(!m.layers.some(l=>l.id==='TABLE'));assert.doesNotMatch(C.svg(layout,only),/id="(?:TABLE|SLOT_EDGES|SURFACE_EDGES)"/);assert.ok(!entities(C.dxf(layout,only)).some(e=>e.some(p=>p[0]===8&&p[1]==='TABLE')));layout.workspace.spaceGuide.kind='guide';assert.equal(C.build(layout).tableAvailable,false);});
test('Copper tape and braid boundaries are kept on distinct layers',()=>{const s=R.settings(),braid=R.definition(s,{type:'straight',lengthMm:500},'braid'),tape=R.definition({...s,conductor:'tape'},{type:'straight',lengthMm:500},'tape'),layout=raw([braid,tape],[F.pose(braid),F.pose(tape,1500,0)]),m=C.build(layout,{...only,conductors:true});assert.ok(m.layers.some(l=>l.id==='BRAID_EDGES'));assert.ok(m.layers.some(l=>l.id==='TAPE_EDGES'));});
test('Sub-millimetre gaps are preserved instead of stretching paths into a manufactured connection',()=>{const d=R.definition(R.settings(),{type:'straight',lengthMm:500}),a=F.pose(d),b={...F.pose(d),x:500.05},m=C.build(raw([d],[a,b]),only);assert.equal(m.paths.length,4);assert.equal(m.openSlots,8);assert.ok(m.messages.some(s=>s.includes('open CAD slot ends')));assert.ok(m.paths.some(p=>p.points[0][0]===500.05));});
test('Unequal verge widths keep unmatched surface caps and report the step',()=>{const a=R.definition(R.settings(),{type:'straight',lengthMm:500},'a'),b=R.definition({...R.defaults,innerClearanceMm:75,outerClearanceMm:125},{type:'straight',lengthMm:500},'b'),defs={a,b},p=F.pose(a),q=F.join(F.pose(b),b,0,F.ports(p,defs)[1]),m=C.build(raw([a,b],[p,q]),{...only,surfaces:true});assert.equal(m.removedCaps,0);assert.ok(m.messages.some(s=>s.includes('step')));assert.equal(m.paths.filter(p=>p.layer==='SLOT_CENTRES').length,2);});
test('Coincident paths are removed once and reported, while closed contours remain closed',()=>{const d=R.definition(R.settings(),{type:'straight',lengthMm:500}),p=F.pose(d),m=C.build(raw([d],[p,{...p,id:'duplicate'}]),{...only,surfaces:true});assert.equal(m.paths.length,3);assert.ok(m.messages.some(s=>s.includes('duplicate path')));});
test('The optional reference bar measures 100 mm and lives on its own layer',()=>{const m=C.build(circular(),{...only,scale:true}),bar=m.paths.filter(p=>p.layer==='SCALE_CHECK');assert.equal(bar.length,3);close(F.dist(bar[0].points[0],bar[0].points[1]),100);assert.ok(bar.every(p=>!p.closed));});
test('Non-routed pieces are excluded explicitly; layout and export data remain immutable',()=>{const layout=circular(),d=F.validateDefinition({id:'custom:plastic',name:'Modular road',parameters:{type:'straight',widthMm:200,lengthMm:350,laneCount:2,laneSpacingMm:100}});layout.definitions.push(d);layout.pieces.push({...F.pose(d),id:'plastic-placement'});const before=structuredClone(layout),m=C.build(layout);assert.equal(m.excluded,1);assert.ok(m.messages[0].includes('non-routed'));C.svg(layout);C.dxf(layout);assert.deepEqual(layout,before);assert.throws(()=>C.build(raw([d],[F.pose(d)])),/routed section/);});
test('Unsupported units, versions, malformed options and empty geometry are rejected',()=>{assert.throws(()=>C.build({...circular(),units:'inches'}),/units/);assert.throws(()=>C.build({...circular(),integration:{contractVersion:'99.0.0'}}),/contract/);assert.throws(()=>C.build(circular(),{slots:'false'}),/true or false/);assert.throws(()=>C.build(circular(),Object.fromEntries(Object.keys(C.defaults).map(k=>[k,false]))),/available geometry layer/);assert.throws(()=>C.build({...circular(),pieces:[]}),/routed section/);});
test('Track titles cannot inject XML elements or DXF records',()=>{const layout=circular();layout.title='Road <script>& " Ω\n0\nEOF\u0001';const svg=C.svg(layout),dxf=C.dxf(layout);assert.match(svg,/&lt;script&gt;&amp;/);assert.doesNotMatch(svg,/<script|\u0001/);assert.match(dxf,/\\U\+03A9/);assert.equal(tags(dxf).filter(p=>p[0]===0&&p[1]==='EOF').length,1);});

test('DXF supplies standard symbol tables and valid unique handles for strict native importers',()=>{
 const pairs=tags(C.dxf(circular())),tables=new Map();
 for(let i=0;i<pairs.length;i++)if(pairs[i][0]===0&&pairs[i][1]==='TABLE'){const name=pairs[i+1][1],start=i;while(pairs[i][1]!=='ENDTAB')i++;tables.set(name,pairs.slice(start,i));}
 assert.deepEqual([...tables.keys()],['VPORT','LTYPE','LAYER','STYLE','VIEW','UCS','APPID','DIMSTYLE','BLOCK_RECORD']);
 for(const [table,name]of[['VPORT','*Active'],['STYLE','Standard'],['APPID','ACAD'],['DIMSTYLE','Standard']])assert.ok(tables.get(table).some(([code,value])=>code===2&&value===name));
 const handles=pairs.filter(([code],i)=>(code===5||code===105)&&pairs[i-1]?.[1]!=='$HANDSEED').map(p=>p[1]);
 assert.equal(new Set(handles).size,handles.length);
 for(const [code,value]of pairs)if([330,340,350,390].includes(code)&&value!=='0')assert.ok(handles.includes(value),'Dangling handle '+value);
 const seed=Number.parseInt(pairs[pairs.findIndex(p=>p[1]==='$HANDSEED')+1][1],16);assert.ok(handles.every(h=>Number.parseInt(h,16)<seed));
 assert.deepEqual(pairs.slice(0,2),[[0,'SECTION'],[2,'HEADER']]);
});

test('DXF layers reference a Normal plot style and model/paper blocks reference their layouts',()=>{
 const pairs=tags(C.dxf(circular())),records=[];let record;
 for(const pair of pairs){if(pair[0]===0){record={type:pair[1],tags:[]};records.push(record);}else if(record)record.tags.push(pair);}
 const value=(r,c)=>r.tags.find(p=>p[0]===c)?.[1],byHandle=new Map(records.filter(r=>value(r,5)).map(r=>[value(r,5),r]));
 const plot=records.find(r=>r.type==='ACDBDICTIONARYWDFLT');assert.ok(plot);assert.equal(value(plot,3),'Normal');assert.equal(value(plot,340),value(plot,350));
 assert.equal(byHandle.get(value(plot,340)).type,'ACDBPLACEHOLDER');
 for(const layer of records.filter(r=>r.type==='LAYER'))assert.equal(value(layer,390),value(plot,340));
 const layouts=records.filter(r=>r.type==='LAYOUT');assert.equal(layouts.length,2);
 for(const block of records.filter(r=>r.type==='BLOCK_RECORD')){const layout=byHandle.get(value(block,340));assert.equal(layout.type,'LAYOUT');assert.equal(layout.tags.filter(p=>p[0]===330).at(-1)[1],value(block,5));}
});

test('Scaled SVG keeps every path intact and restores physical dimensions uniformly',()=>{
 const layout=flowing(),before=structuredClone(layout),full=C.svg(layout,{...only,scale:true}),pathData=svg=>[...svg.matchAll(/<path[^>]*\sd="([^"]+)"/g)].map(m=>m[1]);
 const attr=(svg,name)=>svg.match(new RegExp('\\b'+name+'="([^"]+)"'))[1];
 for(const factor of[5,10,20,50,100]){const svg=C.svg(layout,{...only,scale:true},factor);assert.deepEqual(pathData(svg),pathData(full));assert.equal(attr(svg,'viewBox'),attr(full,'viewBox'));close(parseFloat(attr(svg,'width'))*factor,parseFloat(attr(full,'width')),.0001);close(parseFloat(attr(svg,'height'))*factor,parseFloat(attr(full,'height')),.0001);assert.ok(svg.includes('scaleDenominator&quot;:'+factor));assert.ok(svg.includes('Enlarge to '+factor*100+'%'));}
 assert.deepEqual(layout,before);assert.equal(C.dxf(layout),C.dxf(before));
});

test('Compact SVG chooses a reversible standard scale within its page bounds in either orientation',()=>{
 for(const bounds of[[0,0,3600,1625],[0,0,1625,3600],[-50000,30000,90000,80000]]){const size=C.svgSize({bounds},'compact');assert.ok(size.widthMm<=400&&size.heightMm<=225);close(size.widthMm*size.denominator,bounds[2]+2*size.paddingMm);close(size.heightMm*size.denominator,bounds[3]+2*size.paddingMm);assert.equal(size.restorePercent,size.denominator*100);}
 assert.equal(C.svgSize({bounds:[0,0,3600,1625]},'compact').denominator,10);
});

test('Invalid SVG scales fail explicitly instead of producing incorrect physical dimensions',()=>{
 const model=C.build(circular());for(const value of[0,-1,NaN,Infinity,10001,'50','1:50',null,{}])assert.throws(()=>C.svgSize(model,value),/SVG scale/);
 assert.throws(()=>C.svg(circular(),only,0),/SVG scale/);
});
