// Copied beside active-app.json by the per-user installer.
const fs=require('node:fs/promises'),path=require('node:path'),http=require('node:http'),crypto=require('node:crypto'),{spawn}=require('node:child_process');
function openBrowser(url,{platform=process.platform,spawnProcess=spawn}={}){
 // ShellExecute via Start-Process respects the user's default HTTP browser.
 // Keep the child referenced until handoff completes, including on instance reuse.
 const code="$ErrorActionPreference='Stop'; Start-Process -FilePath '"+url.replaceAll("'","''")+"'";
 const command=platform==='win32'?'powershell.exe':platform==='darwin'?'open':'xdg-open',args=platform==='win32'?['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(code,'utf16le').toString('base64')]:[url];
 return new Promise((resolve,reject)=>{let done=false,child,timer;const finish=error=>{if(done)return;done=true;clearTimeout(timer);if(error)reject(error);else resolve();};try{child=spawnProcess(command,args,{stdio:'ignore',windowsHide:true,detached:platform==='linux'});}catch(e){finish(e);return;}child.once('error',finish);child.once('exit',code=>finish(code===0?null:Error('The default browser opener exited with code '+code+'.')));timer=setTimeout(()=>{child.unref();finish(platform==='linux'?null:Error('The default browser did not confirm opening the app.'));},platform==='linux'?1500:10000);});
}
async function log(home,message){try{const file=path.join(home,'data','launcher.log');await fs.mkdir(path.dirname(file),{recursive:true});try{if((await fs.stat(file)).size>256*1024)await fs.rename(file,file+'.previous');}catch(e){if(e.code!=='ENOENT')throw e;}await fs.appendFile(file,new Date().toISOString()+' '+message+'\n');}catch(e){console.error('Could not write launcher log: '+e.message);}}
function notify(home,message){if(process.platform!=='win32')return;const child=spawn('wscript.exe',[path.join(home,'Start SlotForge.vbs'),message],{stdio:'ignore',windowsHide:true});child.on('error',()=>{});child.unref();}
async function handoff(home,url,opener,notifyUser){await log(home,'App ready: '+url);try{await opener(url);await log(home,'Default browser handoff completed.');}catch(e){await log(home,'Browser handoff failed: '+e.message);console.error('Open this address in a browser: '+url);notifyUser(home,'SlotForge is running, but Windows could not open your browser.\n\nOpen this address yourself:\n'+url+'\n\nDetails: '+path.join(home,'data','launcher.log'));}}
async function launch(home,{port=8173,open=true,browserOpener=openBrowser,notifyUser=notify}={}){
 home=path.resolve(home);const active=JSON.parse(await fs.readFile(path.join(home,'active-app.json'),'utf8')),app=path.resolve(home,active.directory);
 if(!app.startsWith(home+path.sep)||!active.directory.startsWith('app/'))throw Error('Invalid installed app pointer.');
 await fs.access(path.join(app,'.ready.json'));
 const {DiskStore}=require(path.join(app,'app/disk-store.cjs')),{createHandler}=require(path.join(app,'app/serve.cjs')),I=require(path.join(app,'app/integration.js')),store=new DiskStore(path.join(home,'data')),instanceId=crypto.createHash('sha256').update(store.directory).digest('hex');
 // Check the launcher's candidate ports before touching/migrating saved data.
 // An older helper may still write JSON and cannot honour the SQLite marker.
 if(port!==0){const candidates=await Promise.all(Array.from({length:20},async(_,i)=>{try{const response=await fetch(`http://127.0.0.1:${port+i}/api/health`,{signal:AbortSignal.timeout(800)});const health=await response.json();return health.app==='SlotForgeTrackBuilder'&&health.instanceId===instanceId?{health,port:port+i}:null;}catch{return null;}}));
  const live=candidates.filter(Boolean);if(live.some(({health})=>health.version!==I.VERSION||health.buildId!==active.directory||health.storageEngine!=='sqlite'))throw Error('Another Circuit version is still using this data folder. Choose Storage > Stop local app in that copy before updating. No migration was started.');
  if(live.length){const url=`http://127.0.0.1:${live[0].port}/app/`;if(open)await handoff(home,url,browserOpener,notifyUser);else await log(home,'Existing app ready (browser disabled): '+url);return{url,reused:true};}
 }
 const startup=require(path.join(app,'app/storage-startup.cjs')).createStorageStartup(store);if(!startup)await store.init();
 for(let candidate=port;candidate<(port===0?1:port+20);candidate++){
  const options={store,port:candidate,buildId:active.directory,startup},server=http.createServer(createHandler(app,options));options.onQuit=async()=>{if(startup)await startup.close();else await store.close();server.close();server.closeIdleConnections();};
  try{await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(candidate,'127.0.0.1',resolve);});options.port=server.address().port;const url=`http://127.0.0.1:${options.port}/app/`;console.log(JSON.stringify({url,dataDirectory:store.directory,version:I.VERSION}));if(open)await handoff(home,url,browserOpener,notifyUser);else await log(home,'App ready (browser disabled): '+url);return{server,url,reused:false};}
  catch(e){if(e.code!=='EADDRINUSE'){await store.close();throw e;}try{const response=await fetch(`http://127.0.0.1:${candidate}/api/health`,{signal:AbortSignal.timeout(800)}),health=await response.json();if(health.app==='SlotForgeTrackBuilder'&&health.instanceId===instanceId&&health.version===I.VERSION&&health.buildId===active.directory){const url=`http://127.0.0.1:${candidate}/app/`;console.log(JSON.stringify({url,reused:true}));await store.close();if(open)await handoff(home,url,browserOpener,notifyUser);else await log(home,'Existing app ready (browser disabled): '+url);return{url,reused:true};}}catch{}}
 }
 await store.close();
 throw Error('All local SlotForge ports are busy. Stop an older local app and try again.');
}
if(require.main===module){const args=process.argv.slice(2),value=name=>args.includes(name)?args[args.indexOf(name)+1]:undefined,home=path.resolve(value('--home')||__dirname),port=Number(value('--port')||process.env.SLOTFORGE_PORT||8173),open=!args.includes('--no-open')&&process.env.SLOTFORGE_NO_OPEN!=='1';Promise.resolve().then(()=>{if(!Number.isInteger(port)||port<0||port>65515)throw Error('Invalid local port.');return launch(home,{port,open});}).catch(async e=>{console.error(e.message);await log(home,'Startup failed: '+(e.stack||e.message));if(open)notify(home,'SlotForge could not start.\n\n'+e.message+'\n\nDetails: '+path.join(home,'data','launcher.log'));process.exitCode=1;});}
module.exports={launch,openBrowser};
